from distutils.core import setup

setup(
    name='pyaccessories',
    version='1.0',
    packages=[''],
    url='',
    license='',
    author='Devon Mack',
    author_email='devonpmack@gmail.com',
    description='accessories'
)
